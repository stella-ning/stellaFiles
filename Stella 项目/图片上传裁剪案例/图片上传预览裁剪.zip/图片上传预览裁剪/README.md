imgareaselect
=============

基于jquery的图片上传预览裁剪以及上传服务器


upload.html 是上传文件预览

imgsec.html 是图片裁剪预览


index.html 是图片上传剪裁预览并上传服务器

+ change(file) 图片上传预览

+ clacImgZoomParam() 图片等比例拉伸或缩小，记录拉伸比例

+ init()  图片剪裁预览方法
